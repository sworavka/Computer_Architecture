extern long long int test();
extern long long int lab02b();
extern void lab02c(long long int a);
extern long long int lab02d(long long int);

int main(void)
{
	test();
	lab02b();
	lab02c(0);
	lab02d(1);
    return 0;
}
